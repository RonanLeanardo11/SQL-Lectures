--Task 1

CREATE OR REPLACE PROCEDURE AddNewAuthor (
	p_AuthorID Authors.au_id%TYPE,
	p_LName Authors.au_lname%TYPE,
	p_FName Authors.au_fname%TYPE,
	p_phone Authors.phone%TYPE,
	p_address Authors.address%TYPE,
	p_city Authors.city%TYPE,
	p_state Authors.state%TYPE,
	p_country Authors.country%TYPE,
	p_Pcode Authors.postalcode%TYPE) AS

	BEGIN
	-- Insert a new row in the author table.
	INSERT INTO Authors VALUES ( p_AuthorID, p_LName, p_FName, p_phone,p_address,p_city,p_state, p_country, p_Pcode);

END AddNewAuthor;

--Task 2

BEGIN
AddNewAuthor('1234', 'Ryan', 'Darragh', '087123456','Clonmel', 'Tipperary', NULL, 'Ireland', NULL);
END;

--Task 3

CREATE OR REPLACE PROCEDURE EmpSalaries AS

CURSOR emp_cur IS           --creating cursor to retrieve relevant records
 SELECT first_name, last_name, salary, department
 FROM emp_tbl WHERE Salary > 40000
 FOR UPDATE OF salary;

	BEGIN FOR emp_rec in emp_cur LOOP   --open loop and begin update
	UPDATE emp_tbl SET salary = salary-(salary*0.10)
	WHERE CURRENT OF emp_cur;
	
	dbms_output.put_line(emp_rec.first_name || ' ' ||emp_rec.last_name|| ' ' ||emp_rec.salary|| ' ' ||emp_rec.department);  --print current records to screen
	END LOOP;
	
COMMIT;  --make changes permanent 
END;

--Task 4
begin
  empSalaries();
end;

--Task 5 Function

CREATE OR REPLACE FUNCTION CalifornianAuthor(
	p_Fname authors.au_fname%TYPE,
	p_Lname authors.au_lname%TYPE)
	
	RETURN BOOLEAN IS
	v_state 		authors.state%TYPE;
	v_ReturnValue 	BOOLEAN;
	
	BEGIN   -- Get the state for the author name given
		SELECT state
		INTO v_state
		FROM Authors
		WHERE au_fname = p_Fname
		AND au_lname = p_Lname;
		
	-- if the city returned is CA then they are Californian and TRUE is returned. If not then FALSE is returned
	IF (v_state = 'CA') THEN
	v_ReturnValue := TRUE;
	ELSE
	v_ReturnValue := FALSE;
	END IF;
	
	RETURN v_ReturnValue; -- Notice the return statement information being sent back to the calling statement

	END CalifornianAuthor;

	
--Task 6 PL/SQL block to test the code for all authors

DECLARE
	CURSOR c_CalAuthors IS  --create cursur to store first and last name of all authors
	SELECT au_fname, au_lname
	FROM authors;

BEGIN
	FOR v_AuthorRecord IN c_CalAuthors LOOP  --loop to check all records in active set
		IF CalifornianAuthor(v_AuthorRecord.au_fname, v_AuthorRecord.au_lname) THEN -- return if function is true i.e. author leaves in California 
		DBMS_OUTPUT.PUT_LINE( 'The Author called ' || v_AuthorRecord.au_fname||' ' ||v_AuthorRecord.au_lname ||' is Californian!');
		ELSE
		DBMS_OUTPUT.PUT_LINE( 'The Author called ' || v_AuthorRecord.au_fname||' ' ||v_AuthorRecord.au_lname ||' is not Californian!'); --return of function is false
		END IF;
	END LOOP;
END;

